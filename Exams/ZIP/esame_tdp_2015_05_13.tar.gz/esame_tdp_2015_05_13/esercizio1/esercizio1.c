#include "esercizio1.h"

void swap_pairs(Card** cards, int size) {

}
