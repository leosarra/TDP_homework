#include <stdio.h>
#include <stdlib.h>
#include "esercizio.h"

int* sommaColonne(int** mat, int n, int m){
}
