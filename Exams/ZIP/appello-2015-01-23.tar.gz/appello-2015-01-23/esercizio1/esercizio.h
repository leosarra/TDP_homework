#ifndef ESERCIZIO_H
#define ESERCIZIO_H

int* sommaColonne(int** mat, int n, int m);

#endif
