#ifndef ESERCIZIO_H
#define ESERCIZIO_H

int sommatoria(int n, int m);

#endif
