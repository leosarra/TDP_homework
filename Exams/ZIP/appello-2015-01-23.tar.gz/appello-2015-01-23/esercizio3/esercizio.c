#include "esercizio.h"

int sommatoria(int n, int m){
}
