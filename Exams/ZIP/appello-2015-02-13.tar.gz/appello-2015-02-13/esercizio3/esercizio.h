#ifndef ESERCIZIO_H
#define ESERCIZIO_H

int diagonalePrincipale(int** mat, int n);

#endif
