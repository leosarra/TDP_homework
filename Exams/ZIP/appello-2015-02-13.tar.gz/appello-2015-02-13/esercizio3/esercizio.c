#include "esercizio.h"

int diagonalePrincipale(int** mat, int n){
}
