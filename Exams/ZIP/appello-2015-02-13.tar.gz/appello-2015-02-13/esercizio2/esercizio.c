#include <stdio.h>
#include <stdlib.h>
#include "esercizio.h"

void ruota(TipoSCL* pscl, int k){
}

