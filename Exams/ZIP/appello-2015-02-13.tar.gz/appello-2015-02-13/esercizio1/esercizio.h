#ifndef ESERCIZIO_H
#define ESERCIZIO_H

int* accumulaArray(char* nomefile, int* n);

#endif
