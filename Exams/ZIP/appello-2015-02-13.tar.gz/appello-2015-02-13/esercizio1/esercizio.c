#include <stdio.h>
#include <stdlib.h>
#include "esercizio.h"

int* accumulaArray(char* nomefile, int* n){
}
