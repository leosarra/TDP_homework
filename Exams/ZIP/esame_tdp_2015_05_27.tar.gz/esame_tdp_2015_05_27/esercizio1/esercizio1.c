#include <stdlib.h>

#include "esercizio1.h"

int delete_occurrences(TipoSCL* scl, int info) {  

}
