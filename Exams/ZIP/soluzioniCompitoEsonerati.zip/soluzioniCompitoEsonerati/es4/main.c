#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "sort.h"

#define N 20000

int cmp(int* a, int* b) {
    return *a-*b;
}

int is_ordered(int* v, int n) {
    int i;
    for (i=1; i<n; i++) if (v[i-1]>v[i]) return 0;
    return 1;
}

int main() {
    int i, *v = malloc(N*sizeof(v));
    assert(v != NULL);
    for (i=0; i<N; i++) v[i] = i < 1000 ? N-i : i;
    sort(v, N);
    printf("Risultato %s\n", is_ordered(v,N) ? "corretto" : "errato");
    free(v);
    return 0;
}
