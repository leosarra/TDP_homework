#include "sort.h"

void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void sort(int* v, int n) {
    int k, i;
    for (k=0; k<n; k++)
        for (i=1; i<n; i++)
            if (cmp(v+i-1, v+i) > 0) swap(v+i-1, v+i);
}
