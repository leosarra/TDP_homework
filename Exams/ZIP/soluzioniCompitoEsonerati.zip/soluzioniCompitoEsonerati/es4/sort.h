#ifndef __SORT__
#define __SORT__

void swap(int* a, int* b);
int cmp(int* a, int* b);
void sort(int* v, int n);

#endif
