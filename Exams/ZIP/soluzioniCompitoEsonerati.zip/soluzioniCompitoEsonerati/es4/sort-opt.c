#include "sort.h"

void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void sort(int* v, int n) {
    for (;;) {                    // ripete finché l'array non è ordinato...
        int i, sorted = 1;        // assumiamo ottimisticamente che l'array sia ordinato
        for (i=1; i<n; i++)       // scorre l'array e scambia elementi fuori posto...
            if (v[i-1] > v[i]) {  // inlining manuale di cmp
                sorted = 0;       // oops, abbiamo trovato un'inversione => array non ord.
                swap(v+i-1, v+i); // qui non serve fare inlining poiché lo fa gcc -O1
            }
        if (sorted) break;        // usciamo se l'array è ordinato
    }
}
